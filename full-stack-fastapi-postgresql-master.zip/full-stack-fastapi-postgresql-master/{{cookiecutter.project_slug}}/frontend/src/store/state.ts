import { MainState } from './main/state';

export interface State {
    main: MainState;
}
